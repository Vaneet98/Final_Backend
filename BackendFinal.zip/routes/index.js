module.exports = {
  AdminRoutes: require("./AdminRoutes"),
  userRouter: require("./userRoutes"),
  Education: require("./EducationRoute"),
  salary: require("./salaryRoutes"),
};
